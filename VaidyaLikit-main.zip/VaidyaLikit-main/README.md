#Vaidyalikit: 

The app was developed as part of the Smart India Hackathon 2022.

Added the handwritten names of five medicines: Ostocal-D, Nappa, Neuro-B, Maxpro, Ranitid to a tensorflow classification model. Then we created a TensorFlowLite nodel from the previous one, downloaded it and then loaded it into the app.The app uses the camera of the mobilephone and passes the images of the handwritten name to the TensorFlowLite model which then assigns a probability to each of the name. The names are displayed in descending order of the probabilty. 

Credit for the images goes to: http://socialtech.gramweb.net/media-archive/codes

Help for the code:https://www.tensorflow.org/lite/tutorials/model_maker_image_classification
